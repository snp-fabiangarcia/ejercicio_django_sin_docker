-- -----------------------------------------------------
-- Schema django
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `django` DEFAULT CHARACTER SET utf8 ;
USE `django` ;